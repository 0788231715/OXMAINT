# dialects/sqlite/pysqlite.py
# Copyright (C) 2005-2026 the SQLAlchemy authors and contributors
# <see AUTHORS file>
#
# This module is part of SQLAlchemy and is released under
# the MIT License: https://www.opensource.org/licenses/mit-license.php


r"""
.. dialect:: sqlite+pysqlite
    :name: pysqlite
    :dbapi: sqlite3
    :connectstring: sqlite+pysqlite:///file_path
    :url: https://docs.python.org/library/sqlite3.html

    Note that ``pysqlite`` is the same driver as the ``sqlite3``
    module included with the Python distribution.

Driver
------

The ``sqlite3`` Python DBAPI is standard on all modern Python versions;
for cPython and Pypy, no additional installation is necessary.


Connect Strings
---------------

The file specification for the SQLite database is taken as the "database"
portion of the URL.  Note that the format of a SQLAlchemy url is:

.. sourcecode:: text

    driver://user:pass@host/database

This means that the actual filename to be used starts with the characters to
the **right** of the third slash.   So connecting to a relative filepath
looks like::

    # relative path
    e = create_engine("sqlite:///path/to/database.db")

An absolute path, which is denoted by starting with a slash, means you
need **four** slashes::

    # absolute path
    e = create_engine("sqlite:////path/to/database.db")

To use a Windows path, regular drive specifications and backslashes can be
used. Double backslashes are probably needed::

    # absolute path on Windows
    e = create_engine("sqlite:///C:\\path\\to\\database.db")

To use sqlite ``:memory:`` database specify it as the filename using
``sqlite:///:memory:``. It's also the default if no filepath is
present, specifying only ``sqlite://`` and nothing else::

    # in-memory database (note three slashes)
    e = create_engine("sqlite:///:memory:")
    # also in-memory database
    e2 = create_engine("sqlite://")

.. _pysqlite_uri_connections:

URI Connections
^^^^^^^^^^^^^^^

Modern versions of SQLite support an alternative system of connecting using a
`driver level URI <https://www.sqlite.org/uri.html>`_, which has the  advantage
that additional driver-level arguments can be passed including options such as
"read only".   The Python sqlite3 driver supports this mode under modern Python
3 versions.   The SQLAlchemy pysqlite driver supports this mode of use by
specifying "uri=true" in the URL query string.  The SQLite-level "URI" is kept
as the "database" portion of the SQLAlchemy url (that is, following a slash)::

    e = create_engine("sqlite:///file:path/to/database?mode=ro&uri=true")

.. note::  The "uri=true" parameter must appear in the **query string**
   of the URL.  It will not currently work as expected if it is only
   present in the :paramref:`_sa.create_engine.connect_args`
   parameter dictionary.

The logic reconciles the simultaneous presence of SQLAlchemy's query string and
SQLite's query string by separating out the parameters that belong to the
Python sqlite3 driver vs. those that belong to the SQLite URI.  This is
achieved through the use of a fixed list of parameters known to be accepted by
the Python side of the driver.  For example, to include a URL that indicates
the Python sqlite3 "timeout" and "check_same_thread" parameters, along with the
SQLite "mode" and "nolock" parameters, they can all be passed together on the
query string::

    e = create_engine(
        "sqlite:///file:path/to/database?"
        "check_same_thread=true&timeout=10&mode=ro&nolock=1&uri=true"
    )

Above, the pysqlite / sqlite3 DBAPI would be passed arguments as::

    sqlite3.connect(
        "file:path/to/database?mode=ro&nolock=1",
        check_same_thread=True,
        timeout=10,
        uri=True,
    )

Regarding future parameters added to either the Python or native drivers. new
parameter names added to the SQLite URI scheme should be automatically
accommodated by this scheme.  New parameter names added to the Python driver
side can be accommodated by specifying them in the
:paramref:`_sa.create_engine.connect_args` dictionary,
until dialect support is
added by SQLAlchemy.   For the less likely case that the native SQLite driver
adds a new parameter name that overlaps with one of the existing, known Python
driver parameters (such as "timeout" perhaps), SQLAlchemy's dialect would
require adjustment for the URL scheme to continue to support this.

As is always the case for all SQLAlchemy dialects, the entire "URL" process
can be bypassed in :func:`_sa.create_engine` through the use of the
:paramref:`_sa.create_engine.creator`
parameter which allows for a custom callable
that creates a Python sqlite3 driver level connection directly.

.. seealso::

    `Uniform Resource Identifiers <https://www.sqlite.org/uri.html>`_ - in
    the SQLite documentation

.. _pysqlite_regexp:

Regular Expression Support
---------------------------

.. versionadded:: 1.4

Support for the :meth:`_sql.ColumnOperators.regexp_match` operator is provided
using Python's re.search_ function.  SQLite itself does not include a working
regular expression operator; instead, it includes a non-implemented placeholder
operator ``REGEXP`` that calls a user-defined function that must be provided.

SQLAlchemy's implementation makes use of the pysqlite create_function_ hook
as follows::


    def regexp(a, b):
        return re.search(a, b) is not None


    sqlite_connection.create_function(
        "regexp",
        2,
        regexp,
    )

There is currently no support for regular expression flags as a separate
argument, as these are not supported by SQLite's REGEXP operator, however these
may be included inline within the regular expression string.  See `Python regular expressions`_ for
details.

.. seealso::

    `Python regular expressions`_: Documentation for Python's regular expression syntax.

.. _create_function: https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.create_function

.. _re.search: https://docs.python.org/3/library/re.html#re.search

.. _Python regular expressions: https://docs.python.org/3/library/re.html#re.search



Compatibility with sqlite3 "native" date and datetime types
-----------------------------------------------------------

The pysqlite driver includes the sqlite3.PARSE_DECLTYPES and
sqlite3.PARSE_COLNAMES options, which have the effect of any column
or expression explicitly cast as "date" or "timestamp" will be converted
to a Python date or datetime object.  The date and datetime types provided
with the pysqlite dialect are not currently compatible with these options,
since they render the ISO date/datetime including microseconds, which
pysqlite's driver does not.   Additionally, SQLAlchemy does not at
this time automatically render the "cast" syntax required for the
freestanding functions "current_timestamp" and "current_date" to return
datetime/date types natively.   Unfortunately, pysqlite
does not provide the standard DBAPI types in ``cursor.description``,
leaving SQLAlchemy with no way to detect these types on the fly
without expensive per-row type checks.

Keeping in mind that pysqlite's parsing option is not recommended,
nor should be necessary, for use with SQLAlchemy, usage of PARSE_DECLTYPES
can be forced if one configures "native_datetime=True" on create_engine()::

    engine = create_engine(
        "sqlite://",
        connect_args={
            "detect_types": sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
        },
        native_datetime=True,
    )

With this flag enabled, the DATE and TIMESTAMP types (but note - not the
DATETIME or TIME types...confused yet ?) will not perform any bind parameter
or result processing. Execution of "func.current_date()" will return a string.
"func.current_timestamp()" is registered as returning a DATETIME type in
SQLAlchemy, so this function still receives SQLAlchemy-level result
processing.

.. _pysqlite_threading_pooling:

Concurrency/Threading/Pooling Behavior
--------------------------------------

The ``sqlite3`` DBAPI by default prohibits the use of a particular connection
in a thread which is not the one in which it was created.  As SQLite has
matured, it's behavior under multiple threads has improved, and even includes
options for memory only databases to be used in multiple threads.

The thread prohibition is known as "check same thread" and may be controlled
using the ``sqlite3`` parameter ``check_same_thread``, which will disable or
enable this check. SQLAlchemy's default behavior here is to set
``check_same_thread`` to ``False`` automatically whenever a file-based database
is in use, to establish compatibility with the default pool class
:class:`.QueuePool`.

The SQLAlchemy ``pysqlite`` DBAPI establishes the connection pool differently
based on the kind of SQLite database that's requested:

* When a ``:memory:`` SQLite database is specified, the dialect by default
  will use :class:`.SingletonThreadPool`. This pool maintains a single
  connection per thread, so that all access to the engine within the current
  thread use the same ``:memory:`` database - other threads would access a
  different ``:memory:`` database.  The ``check_same_thread`` parameter
  defaults to ``True``.
* When a file-based database is specified, the dialect will use
  :class:`.QueuePool` as the source of connections.   at the same time,
  the ``check_same_thread`` flag is set to False by default unless overridden.

  .. versionchanged:: 2.0

    SQLite file database engines now use :class:`.QueuePool` by default.
    Previously, :class:`.NullPool` were used.  The :class:`.NullPool` class
    may be used by specifying it via the
    :paramref:`_sa.create_engine.poolclass` parameter.

This selection is made based on the database name alone.  Where a
particular pool class is desired, it should be stated explicitly using the
:paramref:`_sa.create_engine.poolclass` parameter, in which case no
selection takes place at all.

.. deprecated:: 2.1

    A URL that passes ``mode=memory`` in the query string is currently also
    given a single-connection pool class.  This behavior is deprecated and
    will be removed in a future release, at which point such URLs will
    receive :class:`.QueuePool` like any other.  This affects URLs such as
    ``sqlite:///file:mydb?mode=memory&cache=shared&uri=true``, for which
    :class:`.QueuePool` is in fact the appropriate class, as a shared cache
    database supports multiple concurrent connections; see
    :ref:`pysqlite_uri_shared_cache`.  Applications relying on the present
    behavior should state the pool class explicitly.

Disabling Connection Pooling for File Databases
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Pooling may be disabled for a file based database by specifying the
:class:`.NullPool` implementation for the :func:`_sa.create_engine.poolclass`
parameter::

    from sqlalchemy import NullPool

    engine = create_engine("sqlite:///myfile.db", poolclass=NullPool)

It's been observed that the :class:`.NullPool` implementation incurs an
extremely small performance overhead for repeated checkouts due to the lack of
connection reuse implemented by :class:`.QueuePool`.  However, it still
may be beneficial to use this class if the application is experiencing
issues with files being locked.

Using a Memory Database in Multiple Threads or Coroutines
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

A ``:memory:`` SQLite database exists only within the scope of a single
DBAPI connection.  It is not possible for two separate ``sqlite3``
connection objects to access the same ``:memory:`` database unless SQLite's
shared-cache feature is enabled.  Without shared cache, each connection
creates its own independent in-memory database.

This means a ``:memory:`` database is **not suitable** for use with
multiple concurrent threads or coroutines unless either:

* All workers are fully serialized (mutexed) against each other
  such that only one is using the database at a time, or
* SQLite's shared-cache URI feature is used to allow multiple
  independent connections to access the same in-memory database.

The same considerations apply when using the :ref:`aiosqlite <aiosqlite>`
dialect, which wraps ``pysqlite`` connections in an async interface —
without shared cache, each connection still creates its own independent
in-memory database.

The recommended approach for multithreaded or async in-memory
use is the shared-cache URI feature, described below.

.. _pysqlite_uri_shared_cache:

Using a Shared-Cache Memory Database
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SQLite's
`URI shared-cache <https://www.sqlite.org/sharedcache.html>`_
mode allows multiple independent DBAPI connections, each with
their own transaction state, to access the same in-memory
database.  This is enabled by using a ``file:`` URI with
``cache=shared`` and passing ``uri=true`` in the query
string::

    engine = create_engine("sqlite:///file::memory:?cache=shared&uri=true")

For async use with aiosqlite, use
:func:`_asyncio.create_async_engine`::

    engine = create_async_engine(
        "sqlite+aiosqlite:///file::memory:?cache=shared&uri=true"
    )

Because this URL form is treated as a file-based database by the
dialect, :class:`.QueuePool` is used automatically and
``check_same_thread`` defaults to ``False``, so no additional pool
or connect_args configuration is needed.  Each checkout from the
pool is a distinct DBAPI connection with its own transaction state.

The shared-cache database is scoped by the filename component of
the URI.  ``file::memory:`` (empty name) is process-global — all
engines in the process that use this URI share the same database.
To maintain multiple independent in-memory databases within the
same process, supply a distinct name for each.  A named database of
this kind requires ``mode=memory``, which presently causes a
single-connection pool to be selected; :class:`.QueuePool` should
therefore be requested explicitly::

    from sqlalchemy.pool import QueuePool

    engine_a = create_engine(
        "sqlite:///file:db_a?mode=memory&cache=shared&uri=true",
        poolclass=QueuePool,
    )
    engine_b = create_engine(
        "sqlite:///file:db_b?mode=memory&cache=shared&uri=true",
        poolclass=QueuePool,
    )

For :func:`_asyncio.create_async_engine`, use
:class:`.AsyncAdaptedQueuePool` in the same way.

.. deprecated:: 2.1

    Selection of a single-connection pool class based on ``mode=memory``
    is deprecated; a future release will use :class:`.QueuePool` for these
    URLs, at which point stating
    :paramref:`_sa.create_engine.poolclass` explicitly will no longer be
    necessary.  See :ref:`pysqlite_threading_pooling`.

.. _pysqlite_shared_cache_lifespan:

Lifespan of a Shared-Cache Memory Database
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A shared-cache in-memory database exists only for as long as at least one
connection to it remains open; when the last connection is closed, the
database and all of its contents are discarded.  A subsequent connection
using the same URI then opens a new, empty database, which typically
surfaces as ``no such table`` errors.

:class:`.QueuePool` retains connections that have been returned to it, so
in a default configuration the database will normally persist once the
first connection has been established.  This is a consequence of pool
behavior rather than a guarantee, however, and the database will be
discarded by ordinary pool operations including:

* :meth:`_engine.Engine.dispose`, which closes all connections currently
  in the pool
* :paramref:`_sa.create_engine.pool_recycle`, as a recycled connection is
  closed before its replacement is opened
* connection invalidation, including that performed by
  :paramref:`_sa.create_engine.pool_pre_ping`
* use of :class:`.NullPool`, which closes each connection as it is
  returned

Where the database must survive independently of pool activity, hold a
single connection open for as long as the database is needed::

    engine = create_engine("sqlite:///file::memory:?cache=shared&uri=true")

    # keep the database alive for the lifetime of the engine
    keepalive = engine.connect()

The same consideration applies to the :ref:`aiosqlite <aiosqlite>`
dialect, using :meth:`_asyncio.AsyncEngine.connect`.

Using StaticPool for Single-Connection Memory Databases
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

An older approach for sharing a ``:memory:`` database among threads
is to force all checkouts to return the same DBAPI connection using
:class:`.StaticPool`.  **This approach does not support any form of
concurrency** and is only useful when all access to the engine is
fully serialized, such as in single-threaded test suites::

    from sqlalchemy.pool import StaticPool

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

.. warning::

    Because :class:`.StaticPool` maintains a single DBAPI connection,
    all :class:`.Session` or :class:`.Connection` objects that use
    this engine share that one underlying connection and its single
    SQLite transaction state.  A ``ROLLBACK`` issued by one session
    (e.g. during error handling) will also roll back uncommitted work
    from any other session, and concurrent ``COMMIT`` / ``ROLLBACK``
    calls can interfere with each other unpredictably.  This approach
    is only appropriate when access to the engine is fully serialized,
    such as in single-threaded test suites.  For concurrent workloads,
    use the shared-cache URI approach described above.

Using Temporary Tables with SQLite
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Due to the way SQLite deals with temporary tables, if you wish to use a
temporary table in a file-based SQLite database across multiple checkouts
from the connection pool, such as when using an ORM :class:`.Session` where
the temporary table should continue to remain after :meth:`.Session.commit` or
:meth:`.Session.rollback` is called, a pool which maintains a single
connection must be used.   Use :class:`.SingletonThreadPool` if the scope is
only needed within the current thread, or :class:`.StaticPool` is scope is
needed within multiple threads for this case::

    # maintain the same connection per thread
    from sqlalchemy.pool import SingletonThreadPool

    engine = create_engine("sqlite:///mydb.db", poolclass=SingletonThreadPool)


    # maintain the same connection across all threads
    from sqlalchemy.pool import StaticPool

    engine = create_engine("sqlite:///mydb.db", poolclass=StaticPool)

Note that :class:`.SingletonThreadPool` should be configured for the number
of threads that are to be used; beyond that number, connections will be
closed out in a non deterministic way.


Dealing with Mixed String / Binary Columns
------------------------------------------------------

The SQLite database is weakly typed, and as such it is possible when using
binary values, which in Python are represented as ``b'some string'``, that a
particular SQLite database can have data values within different rows where
some of them will be returned as a ``b''`` value by the Pysqlite driver, and
others will be returned as Python strings, e.g. ``''`` values.   This situation
is not known to occur if the SQLAlchemy :class:`.LargeBinary` datatype is used
consistently, however if a particular SQLite database has data that was
inserted using the Pysqlite driver directly, or when using the SQLAlchemy
:class:`.String` type which was later changed to :class:`.LargeBinary`, the
table will not be consistently readable because SQLAlchemy's
:class:`.LargeBinary` datatype does not handle strings so it has no way of
"encoding" a value that is in string format.

To deal with a SQLite table that has mixed string / binary data in the
same column, use a custom type that will check each row individually::

    from sqlalchemy import String
    from sqlalchemy import TypeDecorator


    class MixedBinary(TypeDecorator):
        impl = String
        cache_ok = True

        def process_result_value(self, value, dialect):
            if isinstance(value, str):
                value = bytes(value, "utf-8")
            elif value is not None:
                value = bytes(value)

            return value

Then use the above ``MixedBinary`` datatype in the place where
:class:`.LargeBinary` would normally be used.

.. _pysqlite_serializable:

Serializable isolation / Savepoints / Transactional DDL
-------------------------------------------------------

A newly revised version of this important section is now available
at the top level of the SQLAlchemy SQLite documentation, in the section
:ref:`sqlite_transactions`.


.. _pysqlite_udfs:

User-Defined Functions
----------------------

pysqlite supports a `create_function() <https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.create_function>`_
method that allows us to create our own user-defined functions (UDFs) in Python and use them directly in SQLite queries.
These functions are registered with a specific DBAPI Connection.

SQLAlchemy uses connection pooling with file-based SQLite databases, so we need to ensure that the UDF is attached to the
connection when it is created. That is accomplished with an event listener::

    from sqlalchemy import create_engine
    from sqlalchemy import event
    from sqlalchemy import text


    def udf():
        return "udf-ok"


    engine = create_engine("sqlite:///./db_file")


    @event.listens_for(engine, "connect")
    def connect(conn, rec):
        conn.create_function("udf", 0, udf)


    for i in range(5):
        with engine.connect() as conn:
            print(conn.scalar(text("SELECT UDF()")))

"""  # noqa

from __future__ import annotations

import math
import os
import re
import sys
from typing import Any
from typing import Callable
from typing import cast
from typing import Optional
from typing import Pattern
from typing import TYPE_CHECKING
from typing import TypeVar
from typing import Union

from .base import DATE
from .base import DATETIME
from .base import SQLiteDialect
from ... import exc
from ... import pool
from ... import types as sqltypes
from ... import util
from ...util.typing import Self

if TYPE_CHECKING:
    from ...engine.interfaces import ConnectArgsType
    from ...engine.interfaces import DBAPIConnection
    from ...engine.interfaces import DBAPICursor
    from ...engine.interfaces import DBAPIModule
    from ...engine.interfaces import IsolationLevel
    from ...engine.interfaces import ServerVersionInfoType
    from ...engine.url import URL
    from ...pool.base import PoolProxiedConnection
    from ...sql.type_api import _BindProcessorType
    from ...sql.type_api import _ResultProcessorType


class _SQLite_pysqliteTimeStamp(DATETIME):
    def bind_processor(  # type: ignore[override]
        self, dialect: SQLiteDialect
    ) -> Optional[_BindProcessorType[Any]]:
        if dialect.native_datetime:
            return None
        else:
            return DATETIME.bind_processor(self, dialect)

    def result_processor(  # type: ignore[override]
        self, dialect: SQLiteDialect, coltype: object
    ) -> Optional[_ResultProcessorType[Any]]:
        if dialect.native_datetime:
            return None
        else:
            return DATETIME.result_processor(self, dialect, coltype)


class _SQLite_pysqliteDate(DATE):
    def bind_processor(  # type: ignore[override]
        self, dialect: SQLiteDialect
    ) -> Optional[_BindProcessorType[Any]]:
        if dialect.native_datetime:
            return None
        else:
            return DATE.bind_processor(self, dialect)

    def result_processor(  # type: ignore[override]
        self, dialect: SQLiteDialect, coltype: object
    ) -> Optional[_ResultProcessorType[Any]]:
        if dialect.native_datetime:
            return None
        else:
            return DATE.result_processor(self, dialect, coltype)


class SQLiteDialect_pysqlite(SQLiteDialect):
    default_paramstyle = "qmark"
    supports_statement_cache = True
    returns_native_bytes = True

    colspecs = util.update_copy(
        SQLiteDialect.colspecs,
        {
            sqltypes.Date: _SQLite_pysqliteDate,
            sqltypes.TIMESTAMP: _SQLite_pysqliteTimeStamp,
        },
    )

    description_encoding = None

    driver = "pysqlite"

    @classmethod
    def import_dbapi(cls) -> DBAPIModule:
        from sqlite3 import dbapi2 as sqlite

        return cast("DBAPIModule", sqlite)

    @classmethod
    def _is_url_file_db(cls, url: URL) -> bool:
        if (url.database and url.database != ":memory:") and (
            url.query.get("mode", None) != "memory"
        ):
            return True
        else:
            return False

    @classmethod
    def _warn_memory_mode_pool_selection(
        cls,
        url: URL,
        current_pool: type[pool.Pool],
        future_pool: type[pool.Pool],
    ) -> None:
        """Warn when the ``mode=memory`` query string argument is what
        caused a single-connection pool class to be selected.

        See :ticket:`13433`.

        """
        if url.query.get("mode", None) != "memory":
            return

        util.warn_deprecated(
            "Selection of the %s pool class based on the 'mode=memory' "
            "query string argument is deprecated; a future release will "
            "use %s for this URL.  Indicate the intended pool class "
            "using the create_engine.poolclass parameter."
            % (current_pool.__name__, future_pool.__name__),
            "2.1",
            code="sqmp",
        )

    @classmethod
    def get_pool_class(cls, url: URL) -> type[pool.Pool]:
        if cls._is_url_file_db(url):
            return pool.QueuePool
        else:
            cls._warn_memory_mode_pool_selection(
                url, pool.SingletonThreadPool, pool.QueuePool
            )
            return pool.SingletonThreadPool

    def _get_server_version_info(
        self, connection: Any
    ) -> ServerVersionInfoType:
        return self.dbapi.sqlite_version_info  # type: ignore[no-any-return, union-attr]  # noqa: E501

    def retrieve_dbapi_version(self, dbapi: DBAPIModule) -> util.VersionInfo:
        # the ``sqlite3`` module ships with CPython and has no version of
        # its own (the legacy ``sqlite3.version`` attribute was frozen at
        # 2.6.0 and removed in Python 3.14), so the Python version is used
        # here, which is what its feature set actually tracks.  The version
        # of the SQLite library itself is available as
        # :attr:`.Dialect.server_version_info`.
        return util.VersionInfo(sys.version_info[:3])

    _isolation_lookup = SQLiteDialect._isolation_lookup.union(
        {
            "AUTOCOMMIT": None,
        }
    )

    def set_isolation_level(
        self, dbapi_connection: DBAPIConnection, level: IsolationLevel
    ) -> None:
        if level == "AUTOCOMMIT":
            dbapi_connection.isolation_level = None
        else:
            dbapi_connection.isolation_level = ""
            return super().set_isolation_level(dbapi_connection, level)

    def detect_autocommit_setting(self, dbapi_conn: DBAPIConnection) -> bool:
        return dbapi_conn.isolation_level is None

    def on_connect(self) -> Callable[[DBAPIConnection], None]:
        def regexp(a: str, b: Optional[str]) -> Optional[bool]:
            if b is None:
                return None
            return re.search(a, b) is not None

        if self._get_server_version_info(None) >= (3, 9):
            # sqlite must be greater than 3.8.3 for deterministic=True
            # https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.create_function
            # the check is more conservative since there were still issues
            # with following 3.8 sqlite versions
            create_func_kw = {"deterministic": True}
        else:
            create_func_kw = {}

        def set_regexp(dbapi_connection: DBAPIConnection) -> None:
            dbapi_connection.create_function(
                "regexp", 2, regexp, **create_func_kw
            )

        def floor_func(dbapi_connection: DBAPIConnection) -> None:
            # NOTE: floor is optionally present in sqlite 3.35+ , however
            # as it is normally non-present we deliver floor() unconditionally
            # for now.
            # https://www.sqlite.org/lang_mathfunc.html
            dbapi_connection.create_function(
                "floor", 1, math.floor, **create_func_kw
            )

        fns = [set_regexp, floor_func]

        def connect(conn: DBAPIConnection) -> None:
            for fn in fns:
                fn(conn)

        return connect

    def create_connect_args(self, url: URL) -> ConnectArgsType:
        if url.username or url.password or url.host or url.port:
            raise exc.ArgumentError(
                "Invalid SQLite URL: %s\n"
                "Valid SQLite URL forms are:\n"
                " sqlite:///:memory: (or, sqlite://)\n"
                " sqlite:///relative/path/to/file.db\n"
                " sqlite:////absolute/path/to/file.db" % (url,)
            )

        # theoretically, this list can be augmented, at least as far as
        # parameter names accepted by sqlite3/pysqlite, using
        # inspect.getfullargspec().  for the moment this seems like overkill
        # as these parameters don't change very often, and as always,
        # parameters passed to connect_args will always go to the
        # sqlite3/pysqlite driver.
        pysqlite_args = [
            ("uri", bool),
            ("timeout", float),
            ("isolation_level", str),
            ("detect_types", int),
            ("check_same_thread", bool),
            ("cached_statements", int),
        ]
        opts = url.query
        pysqlite_opts: dict[str, Any] = {}
        for key, type_ in pysqlite_args:
            util.coerce_kw_type(opts, key, type_, dest=pysqlite_opts)

        if pysqlite_opts.get("uri", False):
            uri_opts = dict(opts)
            # here, we are actually separating the parameters that go to
            # sqlite3/pysqlite vs. those that go the SQLite URI.  What if
            # two names conflict?  again, this seems to be not the case right
            # now, and in the case that new names are added to
            # either side which overlap, again the sqlite3/pysqlite parameters
            # can be passed through connect_args instead of in the URL.
            # If SQLite native URIs add a parameter like "timeout" that
            # we already have listed here for the python driver, then we need
            # to adjust for that here.
            for key, type_ in pysqlite_args:
                uri_opts.pop(key, None)
            filename: str = url.database  # type: ignore[assignment]
            if uri_opts:
                # sorting of keys is for unit test support
                filename += "?" + (
                    "&".join(
                        "%s=%s" % (key, uri_opts[key])
                        for key in sorted(uri_opts)
                    )
                )
        else:
            # without uri=True, the SQLite URI query string is not in
            # play at all, so anything left over here is silently
            # discarded; warn rather than have it appear to take effect
            ignored = sorted(
                set(opts).difference(key for key, _ in pysqlite_args)
            )
            if ignored:
                util.warn(
                    "Query string argument(s) %s are not accepted by the "
                    "pysqlite driver and are being ignored; SQLite URI "
                    "arguments require that 'uri=true' also be present "
                    "in the URL."
                    % (", ".join("'%s'" % key for key in ignored),),
                    code="squa",
                )

            filename = url.database or ":memory:"
            if filename != ":memory:":
                filename = os.path.abspath(filename)

        pysqlite_opts.setdefault(
            "check_same_thread", not self._is_url_file_db(url)
        )

        return ([filename], pysqlite_opts)

    def is_disconnect(
        self,
        e: DBAPIModule.Error,
        connection: Optional[Union[PoolProxiedConnection, DBAPIConnection]],
        cursor: Optional[DBAPICursor],
    ) -> bool:
        self.dbapi = cast("DBAPIModule", self.dbapi)
        return isinstance(
            e, self.dbapi.ProgrammingError
        ) and "Cannot operate on a closed database." in str(e)


dialect = SQLiteDialect_pysqlite


class _SQLiteDialect_pysqlite_numeric(SQLiteDialect_pysqlite):
    """numeric dialect for testing only

    internal use only.  This dialect is **NOT** supported by SQLAlchemy
    and may change at any time.

    """

    supports_statement_cache = True
    default_paramstyle = "numeric"
    driver = "pysqlite_numeric"

    _first_bind = ":1"
    _not_in_statement_regexp: Optional[Pattern[str]] = None

    def __init__(self, *arg: Any, **kw: Any) -> None:
        kw.setdefault("paramstyle", "numeric")
        super().__init__(*arg, **kw)

    def create_connect_args(self, url: URL) -> ConnectArgsType:
        arg, opts = super().create_connect_args(url)
        opts["factory"] = self._fix_sqlite_issue_99953()
        return arg, opts

    def _fix_sqlite_issue_99953(self) -> Any:
        import sqlite3

        first_bind = self._first_bind
        if self._not_in_statement_regexp:
            nis = self._not_in_statement_regexp

            def _test_sql(sql: str) -> None:
                m = nis.search(sql)
                assert not m, f"Found {nis.pattern!r} in {sql!r}"

        else:

            def _test_sql(sql: str) -> None:
                pass

        def _numeric_param_as_dict(
            parameters: Any,
        ) -> Union[dict[str, Any], tuple[Any, ...]]:
            if parameters:
                assert isinstance(parameters, tuple)
                return {
                    str(idx): value for idx, value in enumerate(parameters, 1)
                }
            else:
                return ()

        class SQLiteFix99953Cursor(sqlite3.Cursor):
            def execute(self, sql: str, parameters: Any = ()) -> Self:
                _test_sql(sql)
                if first_bind in sql:
                    parameters = _numeric_param_as_dict(parameters)
                return super().execute(sql, parameters)

            def executemany(self, sql: str, parameters: Any) -> Self:
                _test_sql(sql)
                if first_bind in sql:
                    parameters = [
                        _numeric_param_as_dict(p) for p in parameters
                    ]
                return super().executemany(sql, parameters)

        class SQLiteFix99953Connection(sqlite3.Connection):
            _CursorT = TypeVar("_CursorT", bound=sqlite3.Cursor)

            def cursor(
                self,
                factory: Optional[
                    Callable[[sqlite3.Connection], _CursorT]
                ] = None,
            ) -> _CursorT:
                if factory is None:
                    factory = SQLiteFix99953Cursor  # type: ignore[assignment]
                return super().cursor(factory=factory)  # type: ignore[return-value]  # noqa[E501]

            def execute(
                self, sql: str, parameters: Any = ()
            ) -> sqlite3.Cursor:
                _test_sql(sql)
                if first_bind in sql:
                    parameters = _numeric_param_as_dict(parameters)
                return super().execute(sql, parameters)

            def executemany(self, sql: str, parameters: Any) -> sqlite3.Cursor:
                _test_sql(sql)
                if first_bind in sql:
                    parameters = [
                        _numeric_param_as_dict(p) for p in parameters
                    ]
                return super().executemany(sql, parameters)

        return SQLiteFix99953Connection


class _SQLiteDialect_pysqlite_dollar(_SQLiteDialect_pysqlite_numeric):
    """numeric dialect that uses $ for testing only

    internal use only.  This dialect is **NOT** supported by SQLAlchemy
    and may change at any time.

    """

    supports_statement_cache = True
    default_paramstyle = "numeric_dollar"
    driver = "pysqlite_dollar"

    _first_bind = "$1"
    _not_in_statement_regexp = re.compile(r"[^\d]:\d+")

    def __init__(self, *arg: Any, **kw: Any) -> None:
        kw.setdefault("paramstyle", "numeric_dollar")
        super().__init__(*arg, **kw)
